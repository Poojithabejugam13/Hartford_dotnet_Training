import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AuthService } from '../services/auth.service';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [CommonModule, RouterModule],
  template: `
  <nav class="bg-indigo-600 text-white p-4 flex justify-between items-center shadow">

    <h1 class="text-xl font-bold">StudentTrainee System</h1>

    <div class="space-x-6">

      <a *ngIf="role==='Admin'" routerLink="/admin">Dashboard</a>
      <a *ngIf="role==='Trainer'" routerLink="/trainer">Dashboard</a>
      <a *ngIf="role==='Student'" routerLink="/student">Dashboard</a>

      <button (click)="logout()"
              class="bg-red-500 px-3 py-1 rounded hover:bg-red-600">
        Logout
      </button>
    </div>

  </nav>
  `
})
export class NavbarComponent {

  role = '';

  constructor(private auth: AuthService) {
    this.role = this.auth.getUserRole();
  }

  logout() {
    this.auth.logout();
  }
}