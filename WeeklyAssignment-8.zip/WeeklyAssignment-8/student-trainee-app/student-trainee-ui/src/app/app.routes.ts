import { Routes } from '@angular/router';
import { LoginComponent } from './pages/login/login';
import { AdminComponent } from './pages/admin/admin';
import { TrainerComponent  } from './pages/trainer/trainer';
import { StudentComponent  } from './pages/student/student';
import { RoleGuard } from './guards/role.guard';
import { ForgotPasswordComponent } from './pages/forgot-password/forgot-password';
import { RegisterComponent } from './pages/register/register';

export const routes: Routes = [

  
  { path: '', redirectTo: 'register', pathMatch: 'full' },

  { path: 'register', component: RegisterComponent },
  { path: 'login', component: LoginComponent },
{ path: 'forgot-password', component: ForgotPasswordComponent },
  
 

  {
  path: 'admin',
  component: AdminComponent,
  canActivate: [RoleGuard],
  data: { role: 'Admin' }
},
{
  path: 'trainer',
  component: TrainerComponent,
  canActivate: [RoleGuard],
  data: { role: 'Trainer' }
},
{
  path: 'student',
  component: StudentComponent,
  canActivate: [RoleGuard],
  data: { role: 'Student' }
},

  { path: '**', redirectTo: 'register' }
];