import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

@Injectable({
  providedIn: 'root'
})
export class RoleGuard implements CanActivate {

  constructor(
    private auth: AuthService,
    private router: Router
  ) {}

  canActivate(route: ActivatedRouteSnapshot): boolean {

    const expectedRole = route.data['role'];   // role from route
    const token = this.auth.getToken();

    
    if (!token) {
      this.router.navigate(['/login']);
      return false;
    }

    const userRole = this.auth.getUserRole();

     
    if (userRole !== expectedRole) {

      if (userRole === 'Admin') {
        this.router.navigate(['/admin']);
      }
      else if (userRole === 'Trainer') {
        this.router.navigate(['/trainer']);
      }
      else if (userRole === 'Student') {
        this.router.navigate(['/student']);
      }
      else {
        this.router.navigate(['/login']);
      }

      return false;
    }

    
    return true;
  }
}