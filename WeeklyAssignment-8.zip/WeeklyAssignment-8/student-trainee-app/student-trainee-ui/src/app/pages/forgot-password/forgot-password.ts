import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../services/auth.service';
import { Router } from '@angular/router';
import { RouterModule } from '@angular/router';
@Component({
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  template: `
  <div class="min-h-screen flex items-center justify-center bg-gradient-to-r from-purple-500 to-pink-600">

    <div class="bg-white p-8 rounded-xl shadow-xl w-96">

      <h2 class="text-2xl font-bold text-center mb-6">
        Forgot Password
      </h2>

      <form (ngSubmit)="submit()" class="space-y-4">

        <input [(ngModel)]="email"
               name="email"
               placeholder="Enter your Email"
               required
               class="w-full p-3 border rounded"/>

        <button class="w-full bg-purple-600 text-white p-3 rounded">
          Send Reset Link
        </button>

      </form>

      <p class="text-sm text-center mt-4">
        <a routerLink="/login" class="text-purple-600 font-semibold">
          Back to Login
        </a>
      </p>

    </div>
  </div>
  `
})
export class ForgotPasswordComponent {

  email = "";

  constructor(private auth: AuthService, private router: Router) {}

  submit() {
    this.auth.forgotPassword({ email: this.email }).subscribe({
      next: () => {
        alert("Reset link sent");
        this.router.navigate(['/login']);
      },
      error: () => alert("Error sending reset link")
    });
  }
}