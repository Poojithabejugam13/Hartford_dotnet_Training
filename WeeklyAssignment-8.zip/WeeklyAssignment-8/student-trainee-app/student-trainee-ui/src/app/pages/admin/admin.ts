import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { NavbarComponent } from '../../components/navbar';

@Component({
  standalone: true,
  imports: [CommonModule, NavbarComponent],
  templateUrl: './admin.html'
})
export class AdminComponent implements OnInit {

  dashboard: any;

  constructor(private http: HttpClient) {}

  ngOnInit() {
    this.http.get('https://localhost:7190/api/admin/dashboard')
      .subscribe(res => this.dashboard = res);
  }
  assign(studentId: number, trainerId: number) {
  this.http.post(
    'https://localhost:7190/api/admin/assign?studentId=' + studentId + '&trainerId=' + trainerId,
    {}
  ).subscribe(() => alert("Assigned successfully"));
}
}