import { Component, AfterViewInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { RouterModule } from '@angular/router';
declare var grecaptcha: any;

@Component({
  standalone: true,
  selector: 'app-register',
  imports: [CommonModule, FormsModule,RouterModule],
  templateUrl: './register.html'
})
export class RegisterComponent implements AfterViewInit {

  model = {
    FullName: '',
    Email: '',
    Password: '',
    Role: ''
  };

  CaptchaToken: string = '';
  widgetId: any;
  isSubmitting = false;

  constructor(private auth: AuthService, private router: Router) {}

  ngAfterViewInit(): void {
    grecaptcha.ready(() => {
      this.widgetId = grecaptcha.render('register-captcha', {
        sitekey: '6Lese3QsAAAAAFF33pQ_sxTMVFtQGYQsQzGbx5jw',
        callback: (token: string) => {
          this.CaptchaToken = token;
        }
      });
    });
  }

  register() {

    if (this.isSubmitting) return;

    if (!this.CaptchaToken) {
      alert("Please complete CAPTCHA");
      return;
    }

    this.isSubmitting = true;

    const payload = {
      FullName: this.model.FullName,
      Email: this.model.Email,
      Password: this.model.Password,
      Role: this.model.Role,
      CaptchaToken: this.CaptchaToken
    };

    console.log("Sending Payload:", payload);  

    this.auth.register(payload).subscribe({
      next: () => {
        alert("Registered Successfully");
        this.router.navigate(['/login']);
      },
      error: (err) => {
        console.log("Backend Error:", err);
        alert(err?.error ?? "Registration Failed");
        grecaptcha.reset(this.widgetId);
        this.CaptchaToken = '';
        this.isSubmitting = false;
      }
    });
  }
}