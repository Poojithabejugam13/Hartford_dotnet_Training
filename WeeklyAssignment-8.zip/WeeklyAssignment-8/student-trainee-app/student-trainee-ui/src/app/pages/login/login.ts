import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { RouterModule } from '@angular/router';
@Component({
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './login.html'
})
export class LoginComponent {

  model: any = {};

  constructor(private auth: AuthService, private router: Router) {}

  login() {
    this.auth.login(this.model).subscribe({
      next: (res) => {
        this.auth.saveToken(res.token);
        const role = this.auth.getUserRole();

        if (role === 'Admin') this.router.navigate(['/admin']);
        if (role === 'Trainer') this.router.navigate(['/trainer']);
        if (role === 'Student') this.router.navigate(['/student']);
      },
      error: () => alert("Invalid credentials")
    });
  }
}