import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { NavbarComponent } from '../../components/navbar';
import { AuthService } from '../../services/auth.service';

@Component({
  standalone: true,
  imports: [CommonModule, NavbarComponent],
  templateUrl: './student.html'
})
export class StudentComponent implements OnInit {

  materials: any[] = [];
  studentName: string = '';    

  constructor(
    private http: HttpClient,
    private auth: AuthService
  ) {}

  ngOnInit() {

    this.studentName = this.auth.getUserName();   

    this.http.get<any[]>('https://localhost:7190/api/student/materials')
      .subscribe(res => this.materials = res);
  }
}