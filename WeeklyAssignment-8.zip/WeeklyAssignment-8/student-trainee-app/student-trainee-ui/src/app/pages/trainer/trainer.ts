import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { NavbarComponent } from '../../components/navbar';
import { AuthService } from '../../services/auth.service';
import { FormsModule } from '@angular/forms';

@Component({
  standalone: true,
  imports: [CommonModule, NavbarComponent, FormsModule],
  templateUrl: './trainer.html'
})
export class TrainerComponent implements OnInit {

  students: any[] = [];
  trainerName: string = '';

  title: string = '';
  description: string = '';
  selectedFile!: File;

  constructor(
    private http: HttpClient,
    private auth: AuthService
  ) {}

  ngOnInit() {

    this.trainerName = this.auth.getUserName();

    this.http.get<any[]>('https://localhost:7190/api/trainer/students')
      .subscribe(res => this.students = res);
  }

  onFileChange(event: any) {
    this.selectedFile = event.target.files[0];
  }

  upload() {

    if (!this.selectedFile) {
      alert("Select a file first");
      return;
    }

    const formData = new FormData();

    formData.append('title', this.title);
    formData.append('description', this.description);
    formData.append('file', this.selectedFile);

    this.http.post(
      'https://localhost:7190/api/trainer/upload',
      formData
    ).subscribe({
      next: () => alert("Uploaded successfully"),
      error: (err) => console.log(err)
    });
  }
}