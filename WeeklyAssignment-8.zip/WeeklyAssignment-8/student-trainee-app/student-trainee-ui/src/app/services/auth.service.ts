import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Injectable({ providedIn: 'root' })
export class AuthService {

  baseUrl = 'https://localhost:7190/api/auth';

  constructor(private http: HttpClient, private router: Router) {}

  login(data: any) {
    return this.http.post<any>(`${this.baseUrl}/login`, data);
  }

  register(data: any) {
    return this.http.post(`${this.baseUrl}/register`, data);
  }
  forgotPassword(data: any) {
  return this.http.post(
    'https://localhost:7190/api/auth/forgot-password',
    data,
    { responseType: 'text' }  
  );
}

  saveToken(token: string) {
    localStorage.setItem('token', token);
  }

  getToken() {
    return localStorage.getItem('token');
  }

  logout() {
    localStorage.removeItem('token');
    this.router.navigate(['/login']);
  }

  // ✅ Manual JWT decode (no library)
  private decodeToken(): any {
    const token = this.getToken();
    if (!token) return null;

    const payload = token.split('.')[1];
    return JSON.parse(atob(payload));
  }

  getUserRole(): string {
    const decoded = this.decodeToken();
    if (!decoded) return '';

    return decoded.role || 
           decoded["http://schemas.microsoft.com/ws/2008/06/identity/claims/role"];
  }

  getUserName(): string {
    const decoded = this.decodeToken();
    if (!decoded) return '';

    return decoded.unique_name ||
           decoded["http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name"];
  }

  isLoggedIn(): boolean {
    return !!this.getToken();
  }
}