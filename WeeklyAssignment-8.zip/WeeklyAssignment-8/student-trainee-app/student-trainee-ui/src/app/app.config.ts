import { ApplicationConfig } from '@angular/core';
import { provideRouter } from '@angular/router';   // ✅ ADD THIS
import { routes } from './app.routes';             // ✅ ADD THIS

import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { TokenInterceptor } from './services/token.interceptor';

export const appConfig: ApplicationConfig = {
  providers: [
    provideRouter(routes),

    provideHttpClient(
      withInterceptors([TokenInterceptor])
    )
  ]
};