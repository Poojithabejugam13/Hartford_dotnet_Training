﻿using System.Text.Json;
using StudentTraineeApp.Domain.Entity;
using StudentTraineeApp.Application.Interfaces;

namespace StudentTraineeApp.InfrastructureLayer.Services
{
    public class CaptchaService : ICaptchaService
    {
        private readonly IConfiguration _config;
        private readonly HttpClient _httpClient;

        public CaptchaService(IConfiguration config, HttpClient httpClient)
        {
            _config = config;
            _httpClient = httpClient;
        }

        public async Task<bool> ValidateCaptcha(string token)
        {
            if (string.IsNullOrEmpty(token))
                return false;

            var secret = _config["GoogleReCaptcha:SecretKey"];

            var response = await _httpClient.PostAsync(
                $"https://www.google.com/recaptcha/api/siteverify?secret={secret}&response={token}",
                null);

            var json = await response.Content.ReadAsStringAsync();
            Console.WriteLine(json);
            var result = JsonSerializer.Deserialize<CaptchaResponse>(
                json,
                new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });

            Console.WriteLine("Google Response: " + json);

            return result?.Success == true;
        }
    }
    public class CaptchaResponse
    {
        public bool Success { get; set; }
    }
}