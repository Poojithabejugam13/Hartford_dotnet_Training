﻿namespace StudentTraineeApp.Application.Interfaces
{
    public interface ICaptchaService
    {
        Task<bool> ValidateCaptcha(string token);
    }
}