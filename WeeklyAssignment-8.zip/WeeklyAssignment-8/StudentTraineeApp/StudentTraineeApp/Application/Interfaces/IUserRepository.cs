﻿using StudentTraineeApp.Domain.Entity;

namespace StudentTraineeApp.Application.Interfaces
{
    public interface IUserRepository
    {
        Task<User> GetByEmailAsync(string email);
        Task AddAsync(User user);
        Task<IEnumerable<User>> GetAllAsync();
    }
}