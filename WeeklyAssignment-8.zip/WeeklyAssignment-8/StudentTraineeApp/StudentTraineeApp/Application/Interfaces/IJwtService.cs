﻿using StudentTraineeApp.Domain.Entity;
namespace StudentTraineeApp.Application.Interfaces
{
    public interface IJwtService
    {
        string GenerateToken(User user);
    }
}
