﻿namespace StudentTraineeApp.Domain.Entity
{
    public class StudyMaterial
{
    public int Id { get; set; }

    public string Title { get; set; }
    public string Description { get; set; }
    public string FileUrl { get; set; }

    public int TrainerId { get; set; }
    public User Trainer { get; set; }
}
}