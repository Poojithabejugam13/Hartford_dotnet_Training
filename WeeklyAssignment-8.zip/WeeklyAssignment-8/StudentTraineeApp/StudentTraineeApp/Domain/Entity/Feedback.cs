﻿namespace StudentTraineeApp.Domain.Entity
{
    public class Feedback
    {
        public int Id { get; set; }
        public int StudentId { get; set; }
        public int TrainerId { get; set; }
        public string Comments { get; set; }
    }
}