﻿public class User
{
    public int UserId { get; set; }

    public string FullName { get; set; }
    public string Email { get; set; }
    public string PasswordHash { get; set; }
    public string Role { get; set; }  

   
    public int? TrainerId { get; set; }
    public User? Trainer { get; set; }

    public ICollection<User>? Students { get; set; }
}