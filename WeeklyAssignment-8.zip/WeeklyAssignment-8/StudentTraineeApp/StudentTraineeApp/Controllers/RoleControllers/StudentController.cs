﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using StudentTraineeApp.Domain.Entity;
using StudentTraineeApp.InfrastructureLayer.Data;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
namespace StudentTraineeApp.Controllers.RoleControllers
{
    [Authorize(Roles = "Student")]
    [ApiController]
    [Route("api/student")]
    public class StudentController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public StudentController(ApplicationDbContext context)
        {
            _context = context;
        }

        // 📌 Get materials of assigned trainer
        [HttpGet("materials")]
        public async Task<IActionResult> GetMaterials()
        {
            var studentId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier).Value);

            var student = await _context.Users.FindAsync(studentId);

            if (student?.TrainerId == null)
                return Ok(new List<StudyMaterial>());

            var materials = await _context.StudyMaterials
                .Where(m => m.TrainerId == student.TrainerId)
                .ToListAsync();

            return Ok(materials);
        }
    }
}