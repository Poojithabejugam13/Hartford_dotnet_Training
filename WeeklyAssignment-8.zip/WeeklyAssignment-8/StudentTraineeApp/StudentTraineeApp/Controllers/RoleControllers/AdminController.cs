﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentTraineeApp.Application.Interfaces;
using StudentTraineeApp.InfrastructureLayer.Data;
namespace StudentTraineeApp.Controllers.RoleControllers
{
    [Authorize(Roles = "Admin")]
    [ApiController]
    [Route("api/admin")]
    public class AdminController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public AdminController(ApplicationDbContext context)
        {
            _context = context;
        }

        // 📌 See all trainers
        [HttpGet("trainers")]
        public async Task<IActionResult> GetTrainers()
        {
            var trainers = await _context.Users
                .Where(u => u.Role == "Trainer")
                .ToListAsync();

            return Ok(trainers);
        }

        // 📌 See all students
        [HttpGet("students")]
        public async Task<IActionResult> GetStudents()
        {
            var students = await _context.Users
                .Where(u => u.Role == "Student")
                .Include(s => s.Trainer)
                .ToListAsync();

            return Ok(students);
        }

        
        [HttpPost("assign")]
        public async Task<IActionResult> AssignStudent(int studentId, int trainerId)
        {
            var student = await _context.Users.FindAsync(studentId);

            if (student == null || student.Role != "Student")
                return BadRequest("Invalid student");

            student.TrainerId = trainerId;

            await _context.SaveChangesAsync();

            return Ok("Student assigned successfully");
        }
    }
}