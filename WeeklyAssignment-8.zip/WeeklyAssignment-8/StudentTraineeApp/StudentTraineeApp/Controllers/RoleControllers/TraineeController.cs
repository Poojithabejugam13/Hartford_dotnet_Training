﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using StudentTraineeApp.Application.Interfaces;
using Microsoft.EntityFrameworkCore;
using StudentTraineeApp.Domain.Entity;
using StudentTraineeApp.InfrastructureLayer.Data;
using System.Security.Claims;
namespace StudentTraineeApp.Controllers.RoleControllers
{
    [Authorize(Roles = "Trainer")]
    [ApiController]
    [Route("api/trainer")]
    public class TrainerController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public TrainerController(ApplicationDbContext context)
        {
            _context = context;
        }

         
        [HttpGet("students")]
        public async Task<IActionResult> GetMyStudents()
        {
            var trainerId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier).Value);

            var students = await _context.Users
                .Where(u => u.TrainerId == trainerId)
                .ToListAsync();

            return Ok(students);
        }

       
        [HttpPost("upload")]
        public async Task<IActionResult> UploadMaterial(StudyMaterial model)
        {
            var trainerId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier).Value);

            model.TrainerId = trainerId;

            _context.StudyMaterials.Add(model);
            await _context.SaveChangesAsync();

            return Ok("Material uploaded");
        }
    }
}