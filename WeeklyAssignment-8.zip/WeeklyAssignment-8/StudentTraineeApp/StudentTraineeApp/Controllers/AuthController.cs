﻿using Microsoft.AspNetCore.Mvc;
using StudentTraineeApp.Application.Interfaces;
using StudentTraineeApp.Domain.Entity;
using StudentTraineeApp.Application.DTOs;
namespace StudentTraineeApp.Controllers
{
    [ApiController]
    [Route("api/auth")]
    public class AuthController : ControllerBase
    {
        private readonly IUserRepository _repo;
        private readonly IJwtService _jwt;
        private readonly ICaptchaService _captcha;

        public AuthController(
            IUserRepository repo,
            IJwtService jwt,
            ICaptchaService captcha)
        {
            _repo = repo;
            _jwt = jwt;
            _captcha = captcha;
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register(RegisterDto model)
        {
            if (!await _captcha.ValidateCaptcha(model.CaptchaToken))
                return BadRequest("Invalid CAPTCHA");

            var existing = await _repo.GetByEmailAsync(model.Email);
            if (existing != null)
                return BadRequest("User already exists");

            var user = new User
            {
                FullName = model.FullName,
                Email = model.Email,
                PasswordHash = BCrypt.Net.BCrypt.HashPassword(model.Password),
                Role = model.Role
            };

            await _repo.AddAsync(user);

            return Ok(new { message = "Registered Successfully" });
        }
        [HttpPost("login")]
        public async Task<IActionResult> Login(LoginDto model)
        {
            var user = await _repo.GetByEmailAsync(model.Email);

            if (user == null)
                return Unauthorized("User not found");

            if (!BCrypt.Net.BCrypt.Verify(model.Password, user.PasswordHash))
                return Unauthorized("Invalid Credentials");

            var token = _jwt.GenerateToken(user);

            return Ok(new { token });
        }

        [HttpPost("forgot-password")]
        public async Task<IActionResult> ForgotPassword(ForgotPasswordDto model)
        {
            var user = await _repo.GetByEmailAsync(model.Email);

            if (user == null)
                return BadRequest("User not found");

            return Ok("Password reset link sent (Demo)");
        }
    }
    }