﻿using JWTExampleII.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;

namespace JWTExampleII.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options)
            : base(options) { }

        public DbSet<Employee> Employees => Set<Employee>();
        public DbSet<User> Users => Set<User>();
    }
}
