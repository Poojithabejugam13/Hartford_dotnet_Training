﻿using System.ComponentModel.DataAnnotations;

namespace RepositoryExample.Models
{
    public class Student
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public string Name { get; set; }

        public ICollection<Course>? Courses { get; set; }
    }
}
