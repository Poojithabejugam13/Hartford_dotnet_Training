﻿using System.ComponentModel.DataAnnotations;

namespace RepositoryExample.Models
{
    public class Course
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public string Title { get; set; }

        public ICollection<Student>? Students { get; set; }
    }
}
