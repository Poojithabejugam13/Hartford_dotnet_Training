﻿using RepositoryExample.Models;

namespace RepositoryExample.Repositories
{
    public interface ICourseRepository
        {
            Task<IEnumerable<Course>> GetAllAsync();
            Task<Course> GetByIdAsync(int id);
            Task AddAsync(Course course);
            Task UpdateAsync(Course course);
            Task DeleteAsync(int id);
        }
    }

 