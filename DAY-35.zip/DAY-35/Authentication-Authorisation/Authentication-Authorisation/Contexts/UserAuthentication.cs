﻿using Microsoft.EntityFrameworkCore;
using Authentication.Models;
namespace Authentication.Contexts
{
    public class UserAuthentication:DbContext
    {
        public UserAuthentication(DbContextOptions<UserAuthentication> options):base(options)
        {
            
        }
         public DbSet<User> Users { get; set; }
    }
}
