﻿using Authentication.Models;
using Authentication.DTOs;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Authentication.Contexts;
using Microsoft.EntityFrameworkCore;
using System;

namespace Authentication.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private readonly UserAuthentication _context;

        public UsersController(UserAuthentication context)
        {
            _context = context;
        }

        // POST: api/users/register
        [HttpPost("register")]
        
        public IActionResult Register(UserDTO userDto)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            var userObj = _context.Users.FirstOrDefault(u => u.email == userDto.email);
            if (userObj == null)
            {
                var user = new User
                {
                    firstName = userDto.firstName,
                    lastName = userDto.lastName,
                    email = userDto.email,
                    password = userDto.password
                };
                _context.Users.Add(user);
                _context.SaveChangesAsync();
                return Ok(userObj);
            }
            else
            {
                return BadRequest("User with this email already exists.");
            }
        }
        [HttpPost("login")]
        
        public IActionResult Login(LoginDTO userDto)
        {
            var validuser = _context.Users.FirstOrDefault(u => u.email == userDto.email && u.password == userDto.password);
            if (validuser == null)
            {
                return NotFound();
            }
            return Ok(validuser);
        }
        [HttpGet]
        
        public IActionResult GetUserProfile(int Userid)
        {
            var user = _context.Users.FirstOrDefault(u => u.UserId == Userid);
            if (user == null)
            {
                return NotFound();
            }
            return Ok(user);
        }
    }
}