﻿namespace Authentication.Models;

public class User
{
    public int UserId { get; set; }
    public string firstName { get; set; }
    public string lastName { get; set; }
    public string email { get; set; }
    public string password { get; set; }
    public bool isActive { get; set; } = true;
    public DateTime date { get; set; }= DateTime.Now;

}
