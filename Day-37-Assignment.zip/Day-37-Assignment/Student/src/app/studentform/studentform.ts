import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { Studentservice } from '../studentservice';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({  
  selector: 'app-studentform',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './studentform.html',
  styleUrls: ['./studentform.css'],
})
export class Studentform implements OnInit {

  student = {
    name: '',
    department: '',
    email: ''
  };

  students: any[] = [];

  constructor(
    private studentService: Studentservice,
    private cd: ChangeDetectorRef   // ✅ added
  ) {}

  ngOnInit() {
    this.loadStudents();
  }

  loadStudents() {
    this.studentService.getStudents().subscribe({
      next: (data) => {
        this.students = data;
        this.cd.detectChanges();   // ✅ FIX
      },
      error: (err) => {
        console.error(err);
      }
    });
  }

  onSubmit() {
    this.studentService.addStudent(this.student).subscribe({
      next: (createdStudent) => {
        alert("Student Added Successfully");
         this.students.push(createdStudent); // Add the new student to the list 
        this.student = {
          name: '',
          department: '',
          email: ''
        };

        this.loadStudents();
        this.cd.detectChanges();                 
      },
      error: (err) => {
        console.error(err);
      }
    });
  }
}
