import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
@Injectable({
  providedIn: 'root',
})
export class Studentservice {
  private apiUrl = 'https://localhost:7208/api/students';

  constructor(private http: HttpClient) { }

  addStudent(student: any) {
    return this.http.post(this.apiUrl, student); 
  }
  getStudents() {
    return this.http.get<any[]>(this.apiUrl);
  }
}
