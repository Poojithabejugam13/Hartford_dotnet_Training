﻿using Microsoft.EntityFrameworkCore;
using StudentBackend.Models;
namespace StudentBackend.Contexts
{
    public class StudentContext : DbContext
    {
        public StudentContext(DbContextOptions<StudentContext> options)
            : base(options) { }

        public DbSet<Student> Students { get; set; }
    }
}
