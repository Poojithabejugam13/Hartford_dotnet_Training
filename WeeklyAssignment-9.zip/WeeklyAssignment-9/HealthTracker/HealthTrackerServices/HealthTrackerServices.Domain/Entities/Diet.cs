using System.ComponentModel.DataAnnotations;

namespace HealthTrackerServices.Domain.Entities
{
    public class Diet
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public string UserId { get; set; } = string.Empty; // From AuthService

        [Required]
        public string MealName { get; set; } = string.Empty;

        public int CaloriesConsumed { get; set; }
        public DateTime Date { get; set; } = DateTime.UtcNow;
    }
}
