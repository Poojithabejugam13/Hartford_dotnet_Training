using System.ComponentModel.DataAnnotations;

namespace HealthTrackerServices.Domain.Entities
{
    public class Activity
    {
        [Key]
        public int Id { get; set; }
        
        [Required]
        public string UserId { get; set; } = string.Empty; // From AuthService
        
        [Required]
        public string ActivityName { get; set; } = string.Empty;
        
        public int DurationMinutes { get; set; }
        public int CaloriesBurned { get; set; }
        public DateTime Date { get; set; } = DateTime.UtcNow;
    }
}
