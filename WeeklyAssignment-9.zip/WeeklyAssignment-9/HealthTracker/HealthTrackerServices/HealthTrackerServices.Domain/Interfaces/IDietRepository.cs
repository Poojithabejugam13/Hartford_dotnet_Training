using System.Collections.Generic;
using System.Threading.Tasks;
using HealthTrackerServices.Domain.Entities;

namespace HealthTrackerServices.Domain.Interfaces
{
    public interface IDietRepository
    {
        Task<IEnumerable<Diet>> GetDietsByUserIdAsync(string userId);
        Task<Diet?> GetDietByIdAsync(int id);
        Task<Diet> AddDietAsync(Diet diet);
        Task UpdateDietAsync(Diet diet);
        Task DeleteDietAsync(int id);
    }
}
