using System.Collections.Generic;
using System.Threading.Tasks;
using HealthTrackerServices.Domain.Entities;

namespace HealthTrackerServices.Domain.Interfaces
{
    public interface IActivityRepository
    {
        Task<IEnumerable<Activity>> GetActivitiesByUserIdAsync(string userId);
        Task<Activity?> GetActivityByIdAsync(int id);
        Task<Activity> AddActivityAsync(Activity activity);
        Task UpdateActivityAsync(Activity activity);
        Task DeleteActivityAsync(int id);
    }
}
