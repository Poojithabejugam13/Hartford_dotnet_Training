using System.Security.Claims;
using System.Threading.Tasks;
using HealthTrackerServices.Application.DTOs;
using HealthTrackerServices.Application.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace HealthTrackerServices.API.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class DietController : ControllerBase
    {
        private readonly IDietService _service;

        public DietController(IDietService service)
        {
            _service = service;
        }

        private string GetUserId() => User.FindFirstValue(ClaimTypes.NameIdentifier) ?? string.Empty;

        [HttpGet]
        public async Task<IActionResult> GetDiets()
        {
            var diets = await _service.GetDietsAsync(GetUserId());
            return Ok(diets);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetDiet(int id)
        {
            var diet = await _service.GetDietByIdAsync(id, GetUserId());
            if (diet == null) return NotFound();
            return Ok(diet);
        }

        [HttpPost]
        public async Task<IActionResult> CreateDiet(CreateDietDto request)
        {
            var diet = await _service.AddDietAsync(request, GetUserId());
            return CreatedAtAction(nameof(GetDiet), new { id = diet.Id }, diet);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateDiet(int id, UpdateDietDto request)
        {
            var updated = await _service.UpdateDietAsync(id, request, GetUserId());
            if (!updated) return NotFound();
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteDiet(int id)
        {
            var deleted = await _service.DeleteDietAsync(id, GetUserId());
            if (!deleted) return NotFound();
            return NoContent();
        }
    }
}
