using System.Security.Claims;
using System.Threading.Tasks;
using HealthTrackerServices.Application.DTOs;
using HealthTrackerServices.Application.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace HealthTrackerServices.API.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class ActivityController : ControllerBase
    {
        private readonly IActivityService _service;

        public ActivityController(IActivityService service)
        {
            _service = service;
        }

        private string GetUserId() => User.FindFirstValue(ClaimTypes.NameIdentifier) ?? string.Empty;

        [HttpGet]
        public async Task<IActionResult> GetActivities()
        {
            var activities = await _service.GetActivitiesAsync(GetUserId());
            return Ok(activities);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetActivity(int id)
        {
            var activity = await _service.GetActivityByIdAsync(id, GetUserId());
            if (activity == null) return NotFound();
            return Ok(activity);
        }

        [HttpPost]
        public async Task<IActionResult> CreateActivity(CreateActivityDto request)
        {
            var activity = await _service.AddActivityAsync(request, GetUserId());
            return CreatedAtAction(nameof(GetActivity), new { id = activity.Id }, activity);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateActivity(int id, UpdateActivityDto request)
        {
            var updated = await _service.UpdateActivityAsync(id, request, GetUserId());
            if (!updated) return NotFound();
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteActivity(int id)
        {
            var deleted = await _service.DeleteActivityAsync(id, GetUserId());
            if (!deleted) return NotFound();
            return NoContent();
        }
    }
}
