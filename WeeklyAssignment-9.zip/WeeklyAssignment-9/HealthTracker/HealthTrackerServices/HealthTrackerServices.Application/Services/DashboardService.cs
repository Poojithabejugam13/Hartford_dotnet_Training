using System.Linq;
using System.Threading.Tasks;
using HealthTrackerServices.Application.DTOs;
using HealthTrackerServices.Application.Interfaces;

namespace HealthTrackerServices.Application.Services
{
    public class DashboardService : IDashboardService
    {
        private readonly IActivityService _activityService;
        private readonly IDietService _dietService;

        public DashboardService(IActivityService activityService, IDietService dietService)
        {
            _activityService = activityService;
            _dietService = dietService;
        }

        public async Task<DashboardSummaryDto> GetDashboardSummaryAsync(string userId)
        {
            var activities = await _activityService.GetActivitiesAsync(userId);
            var diets = await _dietService.GetDietsAsync(userId);

            var totalCaloriesBurned = activities.Sum(a => a.CaloriesBurned);
            var totalCaloriesConsumed = diets.Sum(d => d.CaloriesConsumed);

            return new DashboardSummaryDto
            {
                UserId = userId,
                TotalCaloriesBurned = totalCaloriesBurned,
                TotalCaloriesConsumed = totalCaloriesConsumed,
                RecentActivities = activities.Take(5),
                RecentDiets = diets.Take(5)
            };
        }
    }
}
