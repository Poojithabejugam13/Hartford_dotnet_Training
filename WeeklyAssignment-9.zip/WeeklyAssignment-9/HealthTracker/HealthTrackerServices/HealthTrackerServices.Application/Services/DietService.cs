using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HealthTrackerServices.Application.DTOs;
using HealthTrackerServices.Application.Interfaces;
using HealthTrackerServices.Domain.Entities;
using HealthTrackerServices.Domain.Interfaces;

namespace HealthTrackerServices.Application.Services
{
    public class DietService : IDietService
    {
        private readonly IDietRepository _repository;

        public DietService(IDietRepository repository)
        {
            _repository = repository;
        }

        public async Task<IEnumerable<DietDto>> GetDietsAsync(string userId)
        {
            var diets = await _repository.GetDietsByUserIdAsync(userId);
            return diets.Select(d => new DietDto
            {
                Id = d.Id,
                MealName = d.MealName,
                CaloriesConsumed = d.CaloriesConsumed,
                Date = d.Date
            });
        }

        public async Task<DietDto?> GetDietByIdAsync(int id, string userId)
        {
            var diet = await _repository.GetDietByIdAsync(id);
            if (diet == null || diet.UserId != userId) return null;

            return new DietDto
            {
                Id = diet.Id,
                MealName = diet.MealName,
                CaloriesConsumed = diet.CaloriesConsumed,
                Date = diet.Date
            };
        }

        public async Task<DietDto> AddDietAsync(CreateDietDto request, string userId)
        {
            var diet = new Diet
            {
                UserId = userId,
                MealName = request.MealName,
                CaloriesConsumed = request.CaloriesConsumed,
                Date = System.DateTime.UtcNow
            };

            var createdDiet = await _repository.AddDietAsync(diet);

            return new DietDto
            {
                Id = createdDiet.Id,
                MealName = createdDiet.MealName,
                CaloriesConsumed = createdDiet.CaloriesConsumed,
                Date = createdDiet.Date
            };
        }

        public async Task<bool> UpdateDietAsync(int id, UpdateDietDto request, string userId)
        {
            var diet = await _repository.GetDietByIdAsync(id);
            if (diet == null || diet.UserId != userId) return false;

            diet.MealName = request.MealName;
            diet.CaloriesConsumed = request.CaloriesConsumed;

            await _repository.UpdateDietAsync(diet);
            return true;
        }

        public async Task<bool> DeleteDietAsync(int id, string userId)
        {
            var diet = await _repository.GetDietByIdAsync(id);
            if (diet == null || diet.UserId != userId) return false;

            await _repository.DeleteDietAsync(id);
            return true;
        }
    }
}
