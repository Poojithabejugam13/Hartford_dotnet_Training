using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HealthTrackerServices.Application.DTOs;
using HealthTrackerServices.Application.Interfaces;
using HealthTrackerServices.Domain.Entities;
using HealthTrackerServices.Domain.Interfaces;

namespace HealthTrackerServices.Application.Services
{
    public class ActivityService : IActivityService
    {
        private readonly IActivityRepository _repository;

        public ActivityService(IActivityRepository repository)
        {
            _repository = repository;
        }

        public async Task<IEnumerable<ActivityDto>> GetActivitiesAsync(string userId)
        {
            var activities = await _repository.GetActivitiesByUserIdAsync(userId);
            return activities.Select(a => new ActivityDto
            {
                Id = a.Id,
                ActivityName = a.ActivityName,
                DurationMinutes = a.DurationMinutes,
                CaloriesBurned = a.CaloriesBurned,
                Date = a.Date
            });
        }

        public async Task<ActivityDto?> GetActivityByIdAsync(int id, string userId)
        {
            var activity = await _repository.GetActivityByIdAsync(id);
            if (activity == null || activity.UserId != userId) return null;

            return new ActivityDto
            {
                Id = activity.Id,
                ActivityName = activity.ActivityName,
                DurationMinutes = activity.DurationMinutes,
                CaloriesBurned = activity.CaloriesBurned,
                Date = activity.Date
            };
        }

        public async Task<ActivityDto> AddActivityAsync(CreateActivityDto request, string userId)
        {
            var activity = new Activity
            {
                UserId = userId,
                ActivityName = request.ActivityName,
                DurationMinutes = request.DurationMinutes,
                CaloriesBurned = request.CaloriesBurned,
                Date = System.DateTime.UtcNow
            };

            var createdActivity = await _repository.AddActivityAsync(activity);

            return new ActivityDto
            {
                Id = createdActivity.Id,
                ActivityName = createdActivity.ActivityName,
                DurationMinutes = createdActivity.DurationMinutes,
                CaloriesBurned = createdActivity.CaloriesBurned,
                Date = createdActivity.Date
            };
        }

        public async Task<bool> UpdateActivityAsync(int id, UpdateActivityDto request, string userId)
        {
            var activity = await _repository.GetActivityByIdAsync(id);
            if (activity == null || activity.UserId != userId) return false;

            activity.ActivityName = request.ActivityName;
            activity.DurationMinutes = request.DurationMinutes;
            activity.CaloriesBurned = request.CaloriesBurned;

            await _repository.UpdateActivityAsync(activity);
            return true;
        }

        public async Task<bool> DeleteActivityAsync(int id, string userId)
        {
            var activity = await _repository.GetActivityByIdAsync(id);
            if (activity == null || activity.UserId != userId) return false;

            await _repository.DeleteActivityAsync(id);
            return true;
        }
    }
}
