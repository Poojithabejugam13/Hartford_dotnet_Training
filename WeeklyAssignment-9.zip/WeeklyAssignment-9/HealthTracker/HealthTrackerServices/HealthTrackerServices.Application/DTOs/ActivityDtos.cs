using System;

namespace HealthTrackerServices.Application.DTOs
{
    public class ActivityDto
    {
        public int Id { get; set; }
        public string ActivityName { get; set; } = string.Empty;
        public int DurationMinutes { get; set; }
        public int CaloriesBurned { get; set; }
        public DateTime Date { get; set; }
    }

    public class CreateActivityDto
    {
        public string ActivityName { get; set; } = string.Empty;
        public int DurationMinutes { get; set; }
        public int CaloriesBurned { get; set; }
    }

    public class UpdateActivityDto
    {
        public string ActivityName { get; set; } = string.Empty;
        public int DurationMinutes { get; set; }
        public int CaloriesBurned { get; set; }
    }
}
