using System;

namespace HealthTrackerServices.Application.DTOs
{
    public class DietDto
    {
        public int Id { get; set; }
        public string MealName { get; set; } = string.Empty;
        public int CaloriesConsumed { get; set; }
        public DateTime Date { get; set; }
    }

    public class CreateDietDto
    {
        public string MealName { get; set; } = string.Empty;
        public int CaloriesConsumed { get; set; }
    }

    public class UpdateDietDto
    {
        public string MealName { get; set; } = string.Empty;
        public int CaloriesConsumed { get; set; }
    }
}
