using System.Collections.Generic;

namespace HealthTrackerServices.Application.DTOs
{
    public class DashboardSummaryDto
    {
        public string UserId { get; set; } = string.Empty;
        public int TotalCaloriesBurned { get; set; }
        public int TotalCaloriesConsumed { get; set; }
        public int NetCalories => TotalCaloriesConsumed - TotalCaloriesBurned;
        
        public IEnumerable<ActivityDto> RecentActivities { get; set; } = new List<ActivityDto>();
        public IEnumerable<DietDto> RecentDiets { get; set; } = new List<DietDto>();
    }
}
