using System.Collections.Generic;
using System.Threading.Tasks;
using HealthTrackerServices.Application.DTOs;

namespace HealthTrackerServices.Application.Interfaces
{
    public interface IActivityService
    {
        Task<IEnumerable<ActivityDto>> GetActivitiesAsync(string userId);
        Task<ActivityDto?> GetActivityByIdAsync(int id, string userId);
        Task<ActivityDto> AddActivityAsync(CreateActivityDto request, string userId);
        Task<bool> UpdateActivityAsync(int id, UpdateActivityDto request, string userId);
        Task<bool> DeleteActivityAsync(int id, string userId);
    }
}
