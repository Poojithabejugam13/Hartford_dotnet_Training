using System.Threading.Tasks;
using HealthTrackerServices.Application.DTOs;

namespace HealthTrackerServices.Application.Interfaces
{
    public interface IDashboardService
    {
        Task<DashboardSummaryDto> GetDashboardSummaryAsync(string userId);
    }
}
