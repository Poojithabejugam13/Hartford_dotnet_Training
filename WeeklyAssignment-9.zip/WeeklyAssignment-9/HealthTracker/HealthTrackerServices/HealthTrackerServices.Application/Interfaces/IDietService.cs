using System.Collections.Generic;
using System.Threading.Tasks;
using HealthTrackerServices.Application.DTOs;

namespace HealthTrackerServices.Application.Interfaces
{
    public interface IDietService
    {
        Task<IEnumerable<DietDto>> GetDietsAsync(string userId);
        Task<DietDto?> GetDietByIdAsync(int id, string userId);
        Task<DietDto> AddDietAsync(CreateDietDto request, string userId);
        Task<bool> UpdateDietAsync(int id, UpdateDietDto request, string userId);
        Task<bool> DeleteDietAsync(int id, string userId);
    }
}
