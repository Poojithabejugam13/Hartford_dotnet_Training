using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using HealthTrackerServices.Domain.Entities;
using HealthTrackerServices.Domain.Interfaces;
using HealthTrackerServices.Infrastructure.Data;

namespace HealthTrackerServices.Infrastructure.Repositories
{
    public class DietRepository : IDietRepository
    {
        private readonly HealthTrackerDbContext _context;

        public DietRepository(HealthTrackerDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Diet>> GetDietsByUserIdAsync(string userId)
        {
            return await _context.Diets
                .Where(d => d.UserId == userId)
                .OrderByDescending(d => d.Date)
                .ToListAsync();
        }

        public async Task<Diet?> GetDietByIdAsync(int id)
        {
            return await _context.Diets.FindAsync(id);
        }

        public async Task<Diet> AddDietAsync(Diet diet)
        {
            _context.Diets.Add(diet);
            await _context.SaveChangesAsync();
            return diet;
        }

        public async Task UpdateDietAsync(Diet diet)
        {
            _context.Diets.Update(diet);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteDietAsync(int id)
        {
            var diet = await _context.Diets.FindAsync(id);
            if (diet != null)
            {
                _context.Diets.Remove(diet);
                await _context.SaveChangesAsync();
            }
        }
    }
}
