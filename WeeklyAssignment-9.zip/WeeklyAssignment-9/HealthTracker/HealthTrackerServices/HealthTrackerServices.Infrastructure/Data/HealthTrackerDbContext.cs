using Microsoft.EntityFrameworkCore;
using HealthTrackerServices.Domain.Entities;

namespace HealthTrackerServices.Infrastructure.Data
{
    public class HealthTrackerDbContext : DbContext
    {
        public HealthTrackerDbContext(DbContextOptions<HealthTrackerDbContext> options) : base(options)
        {
        }

        public DbSet<Activity> Activities { get; set; }
        public DbSet<Diet> Diets { get; set; }
    }
}
