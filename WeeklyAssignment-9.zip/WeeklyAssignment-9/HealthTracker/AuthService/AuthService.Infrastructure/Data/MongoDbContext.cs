using AuthService.Domain.Entities;
using Microsoft.Extensions.Configuration;
using MongoDB.Driver;

namespace AuthService.Infrastructure.Data
{
    public class MongoDbContext
    {
        private readonly IMongoDatabase _database;

        public MongoDbContext(IConfiguration configuration)
        {
            var client = new MongoClient(configuration["MongoDBSettings:ConnectionString"]);
            _database = client.GetDatabase(configuration["MongoDBSettings:DatabaseName"]);
        }

        public IMongoCollection<User> Users => _database.GetCollection<User>("Users");
    }
}
